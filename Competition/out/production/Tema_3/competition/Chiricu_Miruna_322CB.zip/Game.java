//package competition;

public interface Game {
    public double accept (RefereeVisitor visitor);
}
