//package competition;

import java.util.ArrayList;

public class BasketballTeam extends Team implements Strategy, Game {

    public BasketballTeam() {
        teamType = "basketball";
    }

    public BasketballTeam(String teamName, String gender, int numberOfPlayers) {
        super(teamName, gender, numberOfPlayers, "basketball");
    }


    @Override
    public double calculateScore() {
        double score = 0;
        for (Player player : players)
            score += player.score;

        score = (double) score/numberOfPlayers;

        return score;
    }

    @Override
    public double accept(RefereeVisitor visitor) {
        return visitor.visit(this);
    }
}
