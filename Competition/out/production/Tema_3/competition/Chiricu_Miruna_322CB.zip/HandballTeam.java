//package competition;

import java.util.ArrayList;

public class HandballTeam extends Team implements Strategy, Game {

    public HandballTeam() {
        teamType = "handball";
    }

    public HandballTeam(String teamName, String gender, int numberOfPlayers) {
        super(teamName, gender, numberOfPlayers, "handball");
    }

    @Override
    public double calculateScore() {
        double score = 0;
        if (gender.equals("masculin"))
            for (Player player : players)
                score += player.score;
        else if (gender.equals("feminin")) {
            score = 1;
            for (Player player : players)
                score *= score;
        }

        return score;
    }

    @Override
    public double accept(RefereeVisitor visitor) {
        return visitor.visit(this);
    }
}
