//package competition;

public class RefereeVisitorImpl implements RefereeVisitor{

    public double visit(BasketballTeam basketballTeam) {
        StrategyContext context = new StrategyContext(basketballTeam);
        return context.executeStrategy();
    }

    public double visit(FootballTeam footballTeam) {
        StrategyContext context = new StrategyContext(footballTeam);
        return context.executeStrategy();
    }

    public double visit(HandballTeam handballTeam) {
        StrategyContext context = new StrategyContext(handballTeam);
        return context.executeStrategy();
    }

}
