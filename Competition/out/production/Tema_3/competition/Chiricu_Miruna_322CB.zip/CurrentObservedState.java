//package competition;

import java.util.ArrayList;

public class CurrentObservedState implements Observer {
    ArrayList<Team> ranking;
    Team team;
    Subject competition;

    public CurrentObservedState(Subject competition, Team team){
        this.competition = competition;
        this.team = team;
        competition.registerObserver(this);
        ranking = new ArrayList<>();
    }

    public void update(ArrayList<Team> ranking) {
        this.ranking = ranking;
    }

    public void displayOwnRank() {
        int rank = 0;
        for (Team team : ranking) {
            rank++;

            if (team == this.team) {
                System.out.println("Echipa " + team.teamName + " a ocupat locul " + rank);
                break;
            }


        }
    }
}
