//package competition;

import java.util.ArrayList;
import java.util.SortedMap;

public interface Observer {
    public void update(ArrayList<Team> teamRanking);
}
