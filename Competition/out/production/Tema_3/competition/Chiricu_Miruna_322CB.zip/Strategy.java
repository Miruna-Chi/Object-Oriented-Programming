//package competition;

import java.util.ArrayList;

public interface Strategy {
    public abstract double calculateScore();
}
