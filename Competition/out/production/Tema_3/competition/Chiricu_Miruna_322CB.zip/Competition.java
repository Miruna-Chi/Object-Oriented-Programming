//package competition;


import java.util.*;

public class Competition implements Subject {
    protected ArrayList<Observer> observers;
    protected String type;
    protected String gender;
    protected ArrayList<Team> teamRanking;
    protected ArrayList<Team> teamsInOrder;

    public Competition() {
        teamRanking = new ArrayList<>();
        teamsInOrder = new ArrayList<>();
        observers = new ArrayList<>();
    }

    public void registerObserver(Observer o) {
        observers.add(o);
    }

    public void removeObserver(Observer o) {
        int i = observers.indexOf(o);
        if (i >= 0) {
            observers.remove(i);
        }
    }

    public void notifyObservers() {
        for (Observer observer : observers) {
            observer.update(teamRanking);
        }
    }

    public void allTeamGame() {

        RefereeVisitor visitor = new RefereeVisitorImpl();

        for (int i = 0; i < teamsInOrder.size(); i++) {
            for (int j = i + 1; j < teamsInOrder.size(); j++) {

                Team team1 = teamsInOrder.get(i);
                Team team2 = teamsInOrder.get(j);

                double score1 = team1.accept(visitor);
                double score2 = team2.accept(visitor);

                if (score1 > score2)
                    team1.gamePoints += 3;
                else if (score1 == score2) {
                    team1.gamePoints += 1;
                    team2.gamePoints += 1;
                } else if (score1 < score2) {
                    team2.gamePoints += 3;
                }

                //System.out.println(team1.teamName + " " + gameScores.get(i) + " " + team2.teamName + " " + gameScores.get(j));
                teamRankUpdate(team1, team1.gamePoints, team2, team2.gamePoints);
            }
        }

    }

    public void teamRankUpdate(Team team1, int score1, Team team2, int score2) {
        //System.out.println(team1.teamName + " " + score1 + " " + team2.teamName + " " + score2);

        teamRanking.remove(team1);
        teamRanking.remove(team2);
        teamRanking.add(team1);
        teamRanking.add(team2);

        Comparator comparator = null;
        teamRanking.sort(comparator);
        notifyObservers();
    }

    public void displayWinners() {
        int rank = 0;
        for (Team team : teamRanking) {
            rank++;

            System.out.println(team.teamName);
            if (rank == 3)
            break;

        }
    }




}
