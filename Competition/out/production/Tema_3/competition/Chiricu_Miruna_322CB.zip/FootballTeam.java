//package competition;

public class FootballTeam extends Team implements Strategy, Game{

    public FootballTeam() {
        teamType = "football";
    }

    public FootballTeam(String teamName, String gender, int numberOfPlayers) {
        super(teamName, gender, numberOfPlayers, "football");
    }

    @Override
    public double calculateScore() {
        double score = 0;
        int minScore = players.get(0).score;
        int maxScore = players.get(0).score;

        for (Player player : players) {
            if (minScore > player.score)
                minScore = player.score;
            if (maxScore < player.score)
                maxScore = player.score;
        }

        for (Player player : players)
            score += player.score;

        if (gender.equals("masculin"))
            score += maxScore;
        else if (gender.equals("feminin"))
            score += minScore;

        return score;
    }

    @Override
    public double accept(RefereeVisitor visitor) {
        return visitor.visit(this);
    }
}
