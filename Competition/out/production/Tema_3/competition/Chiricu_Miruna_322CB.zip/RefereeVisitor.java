//package competition;

public interface RefereeVisitor {
    double visit(BasketballTeam team);
    double visit(FootballTeam team);
    double visit(HandballTeam team);
}
